
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import acm.graphics.*;
import acm.program.GraphicsProgram;


public class Instakilo extends GraphicsProgram implements IKConstants {

	public void run() {
		
	}
	
}

